import "bootstrap-icons/font/bootstrap-icons.css";
import React, { useEffect, useState } from "react";
import imagePlaceholder from '../../Assets/1.jpg';

const ViewEvents = () => {
  const [events, setEvents] = useState([]);
  const BASE_URL = "http://127.0.0.1:8000";


  const fetchEvents = async () => {
    try {
      const token = sessionStorage.getItem("accessToken");
      const teachername = localStorage.getItem("teachername");

      if (!token) {
        console.error("No access token found. Please log in.");
        return;
      }
      if (!teachername) {
        console.error("No teacher name found. Please log in as a teacher.");
        return;
      }

      const response = await fetch(
        `http://127.0.0.1:8000/api/add-event?teachername=${encodeURIComponent(teachername)}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      console.log("Response Status:", response.status);
      const data = await response.json();
      console.log("Fetched Data:", data);

      if (!response.ok) throw new Error("Failed to fetch events");

      const fetchedEvents = data.map((event) => ({
        id: event.id,
        title: event.event_name,
        description: event.description,
        image: event.attachment 
          ? `${BASE_URL}${event.attachment.replace(/^\/media\//, "/media/")}`  // ✅ Fix double `/media/`
          : imagePlaceholder, 
        date: event.date,
        postedBy: event.organizer,
        venue: event.venue,
        time: event.time,
        eventType: event.event_type,
      }));
      

      setEvents(fetchedEvents);
    } catch (error) {
      console.error("Error fetching events:", error);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  const handleDelete = async (eventname) => {
    if (!window.confirm("Are you sure you want to delete this event?"+eventname)) {
      return;
    }
  
    try {
      const token = sessionStorage.getItem("accessToken");
      if (!token) {
        console.error("No access token found. Please log in.");
        return;
      }
  
      const response = await fetch(`http://127.0.0.1:8000/api/delete-event/${eventname}/`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
  
      if (response.ok) {
        alert("Event deleted successfully!");
        setEvents(events.filter(event => event.id !== eventname));
        fetchEvents();  
      } else {
        console.error("Failed to delete event");
      }
    } catch (error) {
      console.error("Error deleting event:", error);
    }
  };
  

  return (
    <div className="container mt-5" style={{ marginTop: "100px",display: "flex", 
      flexDirection: "column" }}>
      <h2 className="text-center mb-4">📢 Events & Hackathons</h2>
      <div className="row" style={{}}>
        {events.map((event, index) => (
          <div className="col-md-4 mb-4" key={index}>
            <div 
              className="card shadow-lg h-100" 
              style={{ 
                margin: "10px", 
                minWidth: "400px", 
                maxWidth: "400px", 
                transition: "transform 0.3s ease, box-shadow 0.3s ease", 
              }}
              onMouseEnter={(e) => e.currentTarget.style.transform = "scale(1.05)"} 
              onMouseLeave={(e) => e.currentTarget.style.transform = "scale(1)"} 
            >
              <img 
                src={event.image} 
                className="card-img-top" 
                alt={event.title} 
                style={{ height: "200px", objectFit: "cover", width: "100%" }} 
              />
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{event.title}</h5>
                <p className="card-text"><strong>Venue:</strong> {event.venue}</p>
                <p className="text-muted">
                  <i className="bi bi-calendar-check"></i> {event.date} &nbsp;
                  <i className="bi bi-clock"></i> {event.time}
                </p>
                <p className="text-muted"><i className="bi bi-person-fill"></i> Organizer: {event.postedBy}</p>
                <p className="text-muted"><strong>Type:</strong> {event.eventType}</p>
                <p className="card-text">Description: {event.description}</p>
                <button 
                  className="btn btn-success mt-auto" 
                  style={{ background: "#C41E3A", border: "none" }} 
                  onClick={()=>handleDelete(event.title)}
                >
                  Delete Event
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ViewEvents;
