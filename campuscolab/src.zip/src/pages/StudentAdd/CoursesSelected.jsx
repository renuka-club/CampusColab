import "bootstrap-icons/font/bootstrap-icons.css";
import React, { useEffect, useState } from "react";
import image1 from "../../Assets/1.jpg"; // Fallback course image

const BASE_URL = "http://127.0.0.1:8000"; // Ensure this is correct

const CoursesSelected = () => {
  const [studentCourses, setStudentCourses] = useState([]); // Store API data
  const studentName = localStorage.getItem("studentname"); // Get student name
  const token = sessionStorage.getItem("accessToken");

  const fetchStudentCourses = async () => {
    try {
      if (!studentName) {
        console.error("No student name found.");
        return;
      }

      const response = await fetch(`${BASE_URL}/api/student-courses/${studentName}/`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to fetch student courses");
      }

      const data = await response.json();
      console.log("Fetched Courses:", data);
      setStudentCourses(data); // Update state with API data
    } catch (error) {
      console.error("Error fetching student courses:", error);
    }
  };

  useEffect(() => {
    fetchStudentCourses();
  }, [studentName]); // Fetch when studentName changes

  return (
    <div className="container mt-5" style={{display:"flex",flexDirection:"column", alignContent:"center"}}>
      <h2 className="text-center" style={{ marginTop: "50px" }}>Courses Joined by Students</h2>
      <div className="row"  style={{width:"100%"}}>
        {studentCourses.length > 0 ? (
          studentCourses.map((course, index) => (
            <div key={index} className="col-md-4 mb-4">
              <div className="card shadow-lg">
                {/* Course Image - Use API Image if available */}
                <img 
                  src={course.course_details?.attachment ? `${BASE_URL}${course.course_details.attachment}` : image1} 
                  className="card-img-top" 
                  style={{ height: "250px", objectFit: "cover" }} 
                  alt={course.course_details?.name || "Course Image"} 
                />
                <div className="card-body">
                  <h5 className="card-title">{course.course_details?.name || "Unknown Course"}</h5>
                  <p className="card-text">{course.course_details?.description || "No description available."}</p>
                  <p className="text-muted">
                    <i className="bi bi-person-circle"></i> Instructor: {course.course_details?.instructor || "N/A"}
                  </p>
                  <p className="text-muted">
                    <i className="bi bi-clock-history"></i> Duration: {course.course_details?.duration || "N/A"} months
                  </p>
                  <p className="text-muted">
                    <i className="bi bi-calendar-check"></i> Start Date: {course.course_details?.start_date || "N/A"}
                  </p>
                  <p className="text-muted">
                    <i className="bi bi-person-fill"></i> Student: {studentName}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-muted">No courses joined yet.</p>
        )}
      </div>
    </div>
  );
};

export default CoursesSelected;
